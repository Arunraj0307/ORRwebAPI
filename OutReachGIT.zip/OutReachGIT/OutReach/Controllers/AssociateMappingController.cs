﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OutReach.Models;
using OutReach.Data.Interface;
using DataModel = OutReach.Data.Models;

namespace OutReach.Controllers
{
    public class AssociateMappingController : ApiController
    {
        public readonly IAssociateMapRepository IAssociateMapRepository;

        public AssociateMappingController(IAssociateMapRepository associateMapRepository)
        {
            IAssociateMapRepository = associateMapRepository;
        }
        // GET: api/AssociateMapping
        [HttpGet]
        [Route("GetValues")]
        public List<DataModel.AssociateMapModels> Get()
        {
            List<DataModel.AssociateMapModels> AssociateMap = new List<DataModel.AssociateMapModels>();
            AssociateMap= IAssociateMapRepository.ReadAssociateMapping();
            return AssociateMap;
        }      

        // POST: api/AssociateMapping
        [HttpPost]
        [Route("InsertValues")]
        public void Post(List<DataModel.AssociateMapModels> associateMap)
        {
            IAssociateMapRepository.InsertAssociateMapping(associateMap);
        }
    }
}
