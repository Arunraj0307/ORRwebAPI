﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OutReach.Models;
using OutReach.Data.Interface;
using DataModel = OutReach.Data.Models;

namespace OutReach.Controllers
{
    public class EventDetailController : ApiController
    {
        public readonly IEventDtlRepository IEventDtlRepository;

        public EventDetailController(IEventDtlRepository eventDtlRepository)
        {
            IEventDtlRepository = eventDtlRepository;
        }
        // GET: api/EventDetail
        [HttpGet]
        [Route("GetValues")]
        public List<DataModel.EventDtlsModels> Get()
        {
            List<DataModel.EventDtlsModels> EventDtls = new List<DataModel.EventDtlsModels>();
            EventDtls = IEventDtlRepository.ReadEventDetails();
            return EventDtls;
        }

        // POST: api/EventDetail
        [HttpPost]
        [Route("InsertValues")]
        public void Post(List<DataModel.EventDtlsModels> eventDtl)
        {
            IEventDtlRepository.InsertEventDetails(eventDtl);
        }
    }
}
