﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;
using DataLayerInterface = OutReach.Data.Interface;
using DataLayerModel = OutReach.Data.Interface;

namespace OutReach.App_Start
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers
            // e.g. container.RegisterType<ITestService, TestService>();

            container.RegisterType<OutReach.Data.Interface.IAssociateDtlRepository, OutReach.Data.Repositories.AssociateDetails.AssocaiteDtlRepository>();
            container.RegisterType<OutReach.Data.Interface.IAssociateMapRepository, OutReach.Data.Repositories.AssociateMappings.AssociateMapRepository>();
            container.RegisterType<OutReach.Data.Interface.IEventDtlRepository, OutReach.Data.Repositories.EventDetails.EventDtlRepository>();         
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}