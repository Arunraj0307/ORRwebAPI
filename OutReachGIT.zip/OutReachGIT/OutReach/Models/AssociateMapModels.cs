﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OutReach.Models
{
    public class AssociateMapModels
    {
        public string EventId { get; set; }
        public string BaseLocation { get; set; }
        public string BenifitName { get; set; }
        public string CouncilName { get; set; }
        public string EventName { get; set; }
        public string EventDesc { get; set; }
        public string EventDate { get; set; }
        public string AssociateId { get; set; }
        public string AssociateName { get; set; }
        public string VoltrHrs { get; set; }
        public string TravelHrs { get; set; }
        public string LivesImpacts { get; set; }
        public string BusinessUnit { get; set; }
        public string Status { get; set; }
        public string IIEPCategory { get; set; }
    }
}

