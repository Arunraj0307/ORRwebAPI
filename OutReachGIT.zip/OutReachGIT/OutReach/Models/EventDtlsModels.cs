﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OutReach.Models
{
    public class EventDtlsModels
    {
        public string EventId { get; set; }
        public string Month { get; set; }
        public string BaseLocation { get; set; }
        public string BenifitName { get; set; }
        public string VenueAddress { get; set; }
        public string CouncilName { get; set; }
        public string Project { get; set; }
        public string Category { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string EventDate { get; set; }
        public string TotalVolunteerNo { get; set; }
        public string TotalVolunteerHrs { get; set; }
        public string TotalTravelHrs { get; set; }
        public string OverAllVolHrs { get; set; }
        public string LivesImpacts { get; set; }
        public string ActivityType { get; set; }
        public string Status { get; set; }
        public string AssociatePOCId { get; set; }
        public string AssociatePOCName { get; set; }
        public string AssociatePOCContNo { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
    }
}