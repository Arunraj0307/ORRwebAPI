﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;

namespace OutReach.Data.Interface
{
    public interface IAssociateMapRepository
    {
        bool InsertAssociateMapping(List<AssociateMapModels> associateMapping);
        List<AssociateMapModels> ReadAssociateMapping();
    }
}
