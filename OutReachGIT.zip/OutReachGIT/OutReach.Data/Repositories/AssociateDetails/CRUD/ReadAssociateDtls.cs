﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;
using System.Data.SqlClient;
using System.Configuration;

namespace OutReach.Data.Repositories.AssociateDetails
{

    public partial class AssocaiteDtlRepository
    {
        #region DBComponent
        string ConnectionString = ConfigurationSettings.AppSettings["OutReachReport"].ToString();
        SqlConnection ConnSqlStr;
        SqlCommand ComSqlStr;
        #endregion

        public List<AssociateDtlsModels> ReadAssociateDetail()
        {
            List<AssociateDtlsModels> AssociateDtls = new List<AssociateDtlsModels>();
            try
            {
                return AssociateDtls;
            }
            catch (Exception)
            {
                return AssociateDtls;
            }
        }
    }
}
