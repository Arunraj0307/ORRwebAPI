﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;
using System.Data.SqlClient;
using System.Configuration;

namespace OutReach.Data.Repositories.AssociateDetails
{
    public partial class AssocaiteDtlRepository
    {
        #region DBComponent
        string ConnectionStr = ConfigurationSettings.AppSettings["OutReachReport"].ToString();
        SqlConnection ConnSql;
        SqlCommand ComSql;
        #endregion

        public bool InsertAssociateDetails(List<AssociateDtlsModels> associateDtls)
        {
            bool IsStatus = false;
            try
            {
                return IsStatus = true;
            }
            catch (Exception)
            {

                return IsStatus;
            }
        }
    }
}
