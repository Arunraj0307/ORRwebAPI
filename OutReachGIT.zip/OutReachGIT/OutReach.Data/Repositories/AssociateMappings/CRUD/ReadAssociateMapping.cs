﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;
using System.Data.SqlClient;
using System.Configuration;

namespace OutReach.Data.Repositories.AssociateMappings
{
    public partial class AssociateMapRepository
    {
        #region DBComponent
        string ConnectionString = ConfigurationSettings.AppSettings["OutReachReport"].ToString();
        SqlConnection ConnSqlStr;
        SqlCommand ComSqlStr;
        #endregion

        public List<AssociateMapModels> ReadAssociateMapping()
        {
            List<AssociateMapModels> AssociateMapping = new List<AssociateMapModels>();
            try
            {
                return AssociateMapping;
            }
            catch (Exception)
            {
                return AssociateMapping;
            }
        }
    }
}
