﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutReach.Data.Models
{
    public class GenericMetricsModel
    {
        public string month { get; set; }
        public int volunteers { get; set; }
        public int volunteeringHrs { get; set; }
    }
}
