﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;
using System.Data;

namespace OutReach.Data.Interface
{
    public interface IAssociateDtlRepository
    {
        bool InsertAssociateDetails(DataTable associateDtls);
        List<AssociateDtlsModels> ReadAssociateDetail();
    }
}
