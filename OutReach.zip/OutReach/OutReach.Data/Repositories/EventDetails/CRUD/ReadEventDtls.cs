﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;
using System.Data.SqlClient;
using System.Configuration;

namespace OutReach.Data.Repositories.EventDetails
{
    public partial class EventDtlRepository
    {
        #region DBComponent
        string ConnectionString = ConfigurationSettings.AppSettings["OutReachReport"].ToString();
        SqlConnection ConnSqlStr;
        SqlCommand ComSqlStr;
        #endregion

        public List<EventDtlsModels> ReadEventDetails()
        {
            List<EventDtlsModels> EventDtls = new List<EventDtlsModels>();
            try
            {
                return EventDtls;
            }
            catch (Exception)
            {
                return EventDtls;
            }
        }
    }
}
