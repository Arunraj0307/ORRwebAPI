﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace OutReach.Data.Repositories.UserDetails
{
    public partial class UserDtlsRepository
    {
        string sqlConfig = ConfigurationManager.ConnectionStrings["OutReachReport"].ToString();
        SqlConnection conSQL;
        SqlCommand commSQL;
        public UserDtlsRepository()
        {
            conSQL = new SqlConnection(sqlConfig);
        }
        public UserDtlsModels Authenticate(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return null;
            var UserDtlsModels = new UserDtlsModels();
            //var user = _context.Users.SingleOrDefault(x => x.Username == username);

            // check if username exists
            if (UserDtlsModels == null)
                return null;

            // check if password is correct
            //if (!VerifyPasswordHash(password, user.PasswordHash, user.PasswordSalt))
            //return null;

            // authentication successful
            return UserDtlsModels;
        }
        public UserDtlsModels Create(UserDtlsModels user, string password)
        {
            DataSet ds = new DataSet();
            // validation
            if (string.IsNullOrWhiteSpace(password)) { }
            //throw new AppException("Password is required");

            string StrQuery = "SELECT * FROM tblUserDtls WHERE UPPER(UserName)='" + user.Username.ToUpper() + "'";
            commSQL = new SqlCommand(StrQuery, conSQL);
            if (conSQL.State == System.Data.ConnectionState.Closed)
                conSQL.Open();
            SqlDataAdapter adp = new SqlDataAdapter(commSQL);
            adp.Fill(ds);
            conSQL.Close();

            //if (_context.Users.Any(x => x.Username == user.Username)) { }
            //throw new AppException("Username \"" + user.Username + "\" is already taken");
            if ((ds.Tables[0].Rows.Count) == 0)
            {
                byte[] passwordHash, passwordSalt;
                CreatePasswordHash(password, out passwordHash, out passwordSalt);

                user.PasswordHash = passwordHash;
                user.PasswordSalt = passwordSalt;
                String StrInsert = "INSERT INTO tblUserDtls(FirstName, LastName, UserName, UserRole, PasswordHash, PasswordSalt)";
                StrInsert += " VALUES('" + user.FirstName + "', '" + user.LastName + "', '" + user.Username + "', '" + user.UserRole + "', @PasswordHash, @PasswordSalt )";
                commSQL = new SqlCommand(StrInsert, conSQL);
                commSQL.Parameters.AddWithValue("@PasswordHash", SqlDbType.Binary).Value = passwordHash;
                commSQL.Parameters.AddWithValue("@PasswordSalt", SqlDbType.Binary).Value = passwordSalt;
                if (conSQL.State == System.Data.ConnectionState.Closed)
                    conSQL.Open();
                commSQL.ExecuteNonQuery();
            }
            return user;
        }
        public void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");

            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

    }
}
