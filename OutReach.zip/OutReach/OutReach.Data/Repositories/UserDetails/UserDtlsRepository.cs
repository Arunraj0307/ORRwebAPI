﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutReach.Data.Interface;

namespace OutReach.Data.Repositories.UserDetails
{
    public partial class UserDtlsRepository : IUserRepository
    {
    }
}
