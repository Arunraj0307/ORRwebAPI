﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OutReach.Models;
using OutReach.Data.Interface;
using DataModel = OutReach.Data.Models;

namespace OutReach.Controllers
{
    
    public class AssociateDetailController : ApiController
    {
        public readonly IAssociateDtlRepository IAssociateDtlRepository;

        public AssociateDetailController(IAssociateDtlRepository associateDtlRepository)
        {
            IAssociateDtlRepository = associateDtlRepository;
        }

        // GET: api/AssociateDetail
        [HttpGet]
        [Route("GetValues")]
        public List<DataModel.AssociateDtlsModels> Get()
        {
            List<DataModel.AssociateDtlsModels> AssociateDtls = new List<DataModel.AssociateDtlsModels>();
            AssociateDtls = IAssociateDtlRepository.ReadAssociateDetail();
            return AssociateDtls;
        }       

        // POST: api/AssociateDetail
        [HttpPost]
        [Route("InsertValues")]
        public int Post(List<DataModel.AssociateDtlsModels> associateDtl)
        {
            //IAssociateDtlRepository.InsertAssociateDetails(associateDtl);
            return 1;
        }

    }
}
