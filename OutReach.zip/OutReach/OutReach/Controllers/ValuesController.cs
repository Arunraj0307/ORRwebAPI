﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OutReach.Models;
using OutReach.Data.Interface;
using DataModel = OutReach.Data.Models;
using repo = OutReach.Data.Repositories;
using System.Data;

namespace OutReach.Controllers
{
    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        // GET: api/AssociateDetail
        [HttpGet]
        [Route("GetValues")]
        public List<DataModel.AssociateDtlsModels> Get()
        {
            List<DataModel.AssociateDtlsModels> AssociateDtls = new List<DataModel.AssociateDtlsModels>();
            //repo.AssociateDetails.AssocaiteDtlRepository associateModel = new repo.AssociateDetails.AssocaiteDtlRepository();
            //AssociateDtls = associateModel.ReadAssociateDetail();
            AssociateDtls.Add(new DataModel.AssociateDtlsModels
            {
            AssociateId="Arun",
            AssociateName="Arunraj",
            Location="Canada",
            Designation="MNG",
            BusinessUnit="Insurance",
            ContactNo="CONTACT"});
            return AssociateDtls;
        }

        // POST: api/AssociateDetail
        [HttpPost]
        [Route("InsertValues")]
        public int Post(List<DataModel.AssociateDtlsModels> associateDtl)
        {
            DataTable AssociateDtl = AssociateDtConfig();
            repo.AssociateDetails.AssocaiteDtlRepository associateModel = new repo.AssociateDetails.AssocaiteDtlRepository();
            foreach(DataModel.AssociateDtlsModels AsscModel in associateDtl)
            {
                AssociateDtl.Rows.Add(AsscModel.AssociateId, AsscModel.AssociateName, AsscModel.Designation, AsscModel.Location, AsscModel.BusinessUnit, AsscModel.ContactNo);
            }
            associateModel.InsertAssociateDetails(AssociateDtl);
            return 1;
        }

        [HttpPost]
        [Route("InsertMappingValues")]
        public int MappingValue(List<DataModel.AssociateMapModels> associateMapMdl)
        {
            DataTable AssociateMapDtl = MappingDtConfig();
            repo.AssociateMappings.AssociateMapRepository associateMapModel = new repo.AssociateMappings.AssociateMapRepository();
            foreach (DataModel.AssociateMapModels AsscMapModel in associateMapMdl)
            {
                AssociateMapDtl.Rows.Add(AsscMapModel.EventId, AsscMapModel.BaseLocation, AsscMapModel.BenifitName, AsscMapModel.CouncilName, AsscMapModel.EventName, AsscMapModel.EventDesc, AsscMapModel.EventDate, AsscMapModel.AssociateId, AsscMapModel.AssociateName, AsscMapModel.VoltrHrs, AsscMapModel.TravelHrs, AsscMapModel.LivesImpacts, AsscMapModel.BusinessUnit, AsscMapModel.Status, AsscMapModel.IIEPCategory);
            }
            associateMapModel.InsertAssociateMapping(AssociateMapDtl);
            return 1;
        }

        [HttpPost]
        [Route("InsertEventValues")]
        public int EventValue(List<DataModel.EventDtlsModels> eventDtl)
        {
            DataTable eventDtlMdl = EventDtConfig();
            repo.EventDetails.EventDtlRepository eventModel = new repo.EventDetails.EventDtlRepository();
            foreach (DataModel.EventDtlsModels evntModel in eventDtl)
            {
                eventDtlMdl.Rows.Add(evntModel.EventId, evntModel.Month, evntModel.BaseLocation, evntModel.BenifitName, evntModel.VenueAddress, evntModel.CouncilName, evntModel.Project, evntModel.Category, evntModel.EventName, evntModel.EventDescription, evntModel.EventDate, evntModel.TotalVolunteerNo, evntModel.TotalVolunteerHrs, evntModel.TotalTravelHrs, evntModel.OverAllVolHrs, evntModel.LivesImpacts, evntModel.ActivityType, evntModel.Status, evntModel.AssociatePOCId, evntModel.AssociatePOCName, evntModel.AssociatePOCContNo, evntModel.ModifiedBy, evntModel.ModifiedOn);
            }
            eventModel.InsertEventDetails(eventDtlMdl);
            return 1;
        }

        [HttpGet]
        [Route("getGenericMetrics")]
        public List<DataModel.GenericMetricsModel> GetGenericMetrics()
        {
            List<DataModel.GenericMetricsModel> GenericMtrs = new List<DataModel.GenericMetricsModel>();
            //repo.AssociateDetails.AssocaiteDtlRepository associateModel = new repo.AssociateDetails.AssocaiteDtlRepository();
            //AssociateDtls = associateModel.ReadAssociateDetail();
            GenericMtrs.Add(new DataModel.GenericMetricsModel
            {
                month = "JAN",
                volunteers = 5,
                volunteeringHrs = 20
            });
            GenericMtrs.Add(new DataModel.GenericMetricsModel
            {
                month = "FEB",
                volunteers = 10,
                volunteeringHrs = 90
            });
            GenericMtrs.Add(new DataModel.GenericMetricsModel
            {
                month = "MAR",
                volunteers = 20,
                volunteeringHrs = 6
            });
            return GenericMtrs;
        }

        public DataTable AssociateDtConfig()
        {
            DataTable AssociateDtl = new DataTable();
            AssociateDtl.Columns.Add("AssociateId");
            AssociateDtl.Columns.Add("AssociateName");
            AssociateDtl.Columns.Add("Designation");
            AssociateDtl.Columns.Add("Location");
            AssociateDtl.Columns.Add("BusinessUnit");
            AssociateDtl.Columns.Add("ContactNo");
            return AssociateDtl;
        }
        public DataTable MappingDtConfig()
        {
            DataTable AssociateMapDtl = new DataTable();
            AssociateMapDtl.Columns.Add("EventId");
            AssociateMapDtl.Columns.Add("BaseLocation");
            AssociateMapDtl.Columns.Add("BenifitName");
            AssociateMapDtl.Columns.Add("CouncilName");
            AssociateMapDtl.Columns.Add("EventName");
            AssociateMapDtl.Columns.Add("EventDesc");
            AssociateMapDtl.Columns.Add("EventDate");
            AssociateMapDtl.Columns.Add("AssociateId");
            AssociateMapDtl.Columns.Add("AssociateName");
            AssociateMapDtl.Columns.Add("VoltrHrs");
            AssociateMapDtl.Columns.Add("TravelHrs");
            AssociateMapDtl.Columns.Add("LivesImpacts");
            AssociateMapDtl.Columns.Add("BusinessUnit");
            AssociateMapDtl.Columns.Add("Status");
            AssociateMapDtl.Columns.Add("IIEPCategory");
            return AssociateMapDtl;
        }
        public DataTable EventDtConfig()
        {
            DataTable eventDtlMdl = new DataTable();
            eventDtlMdl.Columns.Add("EventId");
            eventDtlMdl.Columns.Add("Month");
            eventDtlMdl.Columns.Add("BaseLocation");
            eventDtlMdl.Columns.Add("BenifitName");
            eventDtlMdl.Columns.Add("VenueAddress");
            eventDtlMdl.Columns.Add("CouncilName");
            eventDtlMdl.Columns.Add("Project");
            eventDtlMdl.Columns.Add("Category");
            eventDtlMdl.Columns.Add("EventName");
            eventDtlMdl.Columns.Add("EventDescription");
            eventDtlMdl.Columns.Add("EventDate");
            eventDtlMdl.Columns.Add("TotalVolunteerNo");
            eventDtlMdl.Columns.Add("TotalVolunteerHrs");
            eventDtlMdl.Columns.Add("TotalTravelHrs");
            eventDtlMdl.Columns.Add("OverAllVolHrs");
            eventDtlMdl.Columns.Add("LivesImpacts");
            eventDtlMdl.Columns.Add("ActivityType");
            eventDtlMdl.Columns.Add("Status");
            eventDtlMdl.Columns.Add("AssociatePOCId");
            eventDtlMdl.Columns.Add("AssociatePOCName");
            eventDtlMdl.Columns.Add("AssociatePOCContNo");
            eventDtlMdl.Columns.Add("ModifiedBy");
            eventDtlMdl.Columns.Add("ModifiedOn");
            return eventDtlMdl;
        }

        // GET api/values
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/values/5
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/values
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/values/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/values/5
        //public void Delete(int id)
        //{
        //}
    }
}
