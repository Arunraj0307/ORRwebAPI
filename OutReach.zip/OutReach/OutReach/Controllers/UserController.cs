﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OutReach.Models;
using OutReach.Data.Repositories.UserDetails;
using OutReach.Data.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using OutReach.Models;
//using Microsoft.AspNetCore.Mvc;

namespace OutReach.Controllers
{
    [RoutePrefix("api/User")]
    public class UserController : ApiController
    {
        private readonly AppSettings _appSettings;
        UserDtlsRepository userRepo;
        public UserController()
        { userRepo = new UserDtlsRepository();
            
        }

        [AllowAnonymous]     
        [HttpPost]
        [Route("register")]
        public bool Register(UserModel userDto)
        {
            // map dto to entity
            //var user = _mapper.Map<User>(userDto);
            UserDtlsModels userDtl = new UserDtlsModels();
            userDtl.FirstName = userDto.FirstName;
            userDtl.LastName = userDto.LastName;
            userDtl.Username = userDto.Username;
            userDtl.UserRole = userDto.Role;            
            try
            {
                // save 
                userRepo.Create(userDtl, userDto.Password);
                return true;
            }
            catch (Exception ex)
            {
                // return error message if there was an exception
                return false;
            }
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("authenticate")]
        public UserModel Authenticate(UserModel userDto)
        {
            var user = userRepo.Authenticate(userDto.Username, userDto.Password);

            //if (user == null)
            //    return BadRequest(new { message = "Username or password is incorrect" });
            var tokenHandler = new JwtSecurityTokenHandler();
            //var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            //var tokenDescriptor = new SecurityTokenDescriptor
            //{
            //    Subject = new ClaimsIdentity(new Claim[]
            //    {
            //        new Claim(ClaimTypes.Name, user.Id.ToString())
            //    }),
            //    Expires = DateTime.UtcNow.AddDays(7),
            //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            //};
            //var token = tokenHandler.CreateToken(tokenDescriptor);
            //var tokenString = tokenHandler.WriteToken(token);
            UserModel usrModel = new Models.UserModel();
            usrModel.FirstName = user.FirstName;
            usrModel.LastName = user.LastName;
            usrModel.Username = user.Username;
            usrModel.Role = user.UserRole;
            usrModel.token = "askjhsdfhnsajdk551261r2387";

            // return basic user info (without password) and token to store client side
            return usrModel;
        }
    }

    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
